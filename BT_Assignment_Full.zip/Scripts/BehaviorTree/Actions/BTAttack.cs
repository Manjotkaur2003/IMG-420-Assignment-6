using Godot;

/// <summary>
/// Action: Enemy performs an attack on Player if in range and cooldown ready.
/// </summary>
public partial class BTAttack : BTNode
{
    public override Status Execute()
    {
        if (!Enemy.CanAttack()) return Status.Failure;

        Enemy.DoAttack(Player);
        return Status.Success;
    }
}
