using Godot;

/// <summary>
/// Action: Enemy summons an Ally using AllyScene, adds to Allies group.
/// </summary>
public partial class BTSummonAlly : BTNode
{
    public override Status Execute()
    {
        if (Enemy.AllyScene == null) return Status.Failure;

        Ally ally = Enemy.AllyScene.Instantiate<Ally>();
        ally.GlobalPosition = Enemy.GlobalPosition + new Vector2(24, 0);
        Enemy.GetTree().CurrentScene.AddChild(ally);
        ally.AddToGroup("Allies");

        return Status.Success;
    }
}
