using Godot;
using System.Linq;

/// <summary>
/// Condition: Success if there is at least one node in group "Allies".
/// </summary>
public partial class BTAreAlliesAvailable : BTNode
{
    public override Status Execute()
    {
        var allies = Enemy.GetTree().GetNodesInGroup("Allies");
        return allies.Count > 0 ? Status.Success : Status.Failure;
    }
}
