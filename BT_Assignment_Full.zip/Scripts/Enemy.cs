using Godot;

/// <summary>
/// Enemy driven by a Behavior Tree defined as children of its BehaviorTree node.
/// </summary>
public partial class Enemy : CharacterBody2D
{
    [Export] public float MoveSpeed = 100f;
    [Export] public float PatrolSpeed = 60f;
    [Export] public float MaxHealth = 100f;
    [Export] public float AttackDamage = 10f;
    [Export] public float AttackCooldownSeconds = 1.0f;
    [Export] public PackedScene AllyScene;

    public float Health;

    private float _attackCooldown;
    private Player _player;
    private BTNode _root;

    public override void _Ready()
    {
        Health = MaxHealth;

        // Assumes Main.tscn has Player at path "Main/Player"
        _player = GetTree().Root.GetNode<Player>("Main/Player");

        // BehaviorTree node must be a BTSelector / BTNode root
        _root = GetNodeOrNull<BTNode>("BehaviorTree");
        if (_root == null)
        {
            GD.PrintErr("BehaviorTree node with BTNode script not found under Enemy.");
            return;
        }

        _root.Initialize(this, _player);
    }

    public override void _PhysicsProcess(double delta)
    {
        if (_attackCooldown > 0)
            _attackCooldown -= (float)delta;

        _root?.Execute();

        QueueRedraw();
    }

    public bool CanAttack() => _attackCooldown <= 0f;

    public void ResetAttackCooldown()
    {
        _attackCooldown = AttackCooldownSeconds;
    }

    public void DoAttack(Player player)
    {
        if (player != null)
        {
            // Hook up to real player health system if desired
            GD.Print("Enemy attacks player!");
        }
        ResetAttackCooldown();
    }

    public void TakeDamage(float dmg)
    {
        Health -= dmg;
        if (Health <= 0)
            QueueFree();
    }

    public override void _Draw()
    {
        // Extra credit: debug rings for detection/attack ranges (tweak radii as needed)
        DrawCircle(Vector2.Zero, 200, new Color(1, 1, 0, 0.15f));
        DrawCircle(Vector2.Zero,  50, new Color(1, 0, 0, 0.15f));
    }
}
